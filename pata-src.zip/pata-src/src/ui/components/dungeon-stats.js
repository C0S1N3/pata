import {html} from '../lib.js'

export default function DungeonStats({dungeon}) {
	const stats = getEnemiesStats(dungeon)
	return html`
		<h2>本局战绩</h2>
		<ul>
			<li>遭遇敌人：${stats.encountered}</li>
			<li>击杀敌人：${stats.killed}</li>
			<li>敌人总生命：${stats.maxHealth}</li>
			<li>剩余生命合计：${stats.finalHealth}</li>
		</ul>
	`
}

export const getEnemiesStats = (dungeon) => {
	const stats = {
		killed: 0,
		encountered: 0,
		maxHealth: 0,
		finalHealth: 0,
	}
	if (!dungeon.graph) throw new Error('Missing dungeon graph')
	/* for each path taken (room) in the dungeon, get some stats */
	dungeon.pathTaken.forEach(([x, y]) => {
		const nodeData = dungeon.graph[y][x]
		/* find some stats about the enemies encountered */
		if (nodeData.room?.monsters) {
			/* how many encountered monsters */
			stats.encountered += nodeData.room.monsters.length
			nodeData.room.monsters.forEach((monster) => {
				/* how many killed monsters? */
				if (monster.currentHealth <= 0) {
					stats.killed += 1
				}
				/* monsters total life */
				stats.finalHealth += monster.currentHealth
				stats.maxHealth += monster.maxHealth
			})
		}
	})
	return stats
}
