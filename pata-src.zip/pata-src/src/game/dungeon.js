import {bosses, elites, monsters} from '../content/monster-rooms.js'
import {pick, random as randomBetween, shuffle, uuid} from '../utils.js'
import {CampfireRoom, StartRoom} from './rooms.js'

/**
 * A procedural generated dungeon map for Slay the Web. Again, heavily inspired by Slay the Spire.
 *
 * Vocabulary from top to bottom:
 * - "dungeon": the full structure with graph, paths, and current position
 * - "graph": 2d array of floors, each floor is an array of nodes
 * - "floor": one row of nodes (graph[y] is a floor)
 * - "node": a single point on the map at graph[y][x]
 * - "room": content of a node (monster, campfire, etc)
 * - "paths": pre-generated possible routes from start to boss (4 paths in default dungeon)
 * - "pathTaken": the actual route the player chose (grows as they play)
 * - "edges": which nodes connect to which (derived from paths, stored as node IDs on each node)
 * - "move": [y, x] coordinates
 */

/** @typedef {import('./cards.js').CARD} Card */
/** @typedef {import('./rooms.js').Room} Room */

/**
 * @typedef {object} MapNode - is a single point on the map. It will either contain a room, or be a filler node.
 * @prop {string} id
 * @prop {MapNodeTypes} type
 * @prop {Room} [room]
 * @prop {Array<string>} edges - a list of node ids that this node connects to
 * @prop {boolean} didVisit - whether you have visited this node or not
 */
/** @typedef {Array<Array<MapNode>>} Graph is a list of floors with nodes*/
/** @typedef {Array<Array<Move>>} Path is a list of moves that describe a path from top to bottom */
/** @typedef {{x: number, y: number}} Position on the map. Y is the floor. X is the node. */
/** @typedef {Array<number, number>} Move also position map, but stored differently */

/**
 * @typedef {object} GraphOptions
 * @prop {number} width how many nodes on each floor
 * @prop {number} height how many floors
 * @prop {number} [minRooms] minimum amount of rooms to generate per floor
 * @prop {number} [maxRooms] maximum amount of rooms to generate per floor
 * @prop {string} [roomTypes] a string like "MMCE". Repeat a letter to increase the chance of it appearing. M=Monster, C=Campfire, E=Elite. For example "MMMCE" gives 60% chance of a monster, 20% chance of a campfire and 20% chance of an elite.
 * @prop {string} [customPaths] a string of indexes (numbers) from where to draw the paths, for example "530" would draw three paths. First at index 5, then 3 and finally 0.
 */

/** @type {GraphOptions} */
export const defaultOptions = {
	width: 10,
	height: 6,
	minRooms: 2,
	maxRooms: 5,
	roomTypes: 'MMMCE',
	// customPaths: '123'
}

/**
 * @typedef {object} Dungeon An instance of a dungeon
 * @prop {string} id a unique id
 * @prop {Graph} graph
 * @prop {Array<Path>} paths
 * @prop {number} x current x position (which path)
 * @prop {number} y current y position (where on the path)
 * @prop {Array<Move>} pathTaken a list of moves we've taken
 */

/**
 * Creates a new dungeon, complete with graph and paths.
 * @param {GraphOptions} [options]
 * @returns {Dungeon}
 */
export default function Dungeon(options) {
	options = Object.assign(defaultOptions, options)

	const graph = generateGraph(options)
	const paths = generatePaths(graph, options.customPaths)

	// Add "room" to all valid node in the graph.
	graph.forEach((floor, floorNumber) => {
		floor.forEach((node) => {
			if (node.type) {
				node.room = decideRoomType(node.type, floorNumber)
			}
		})
	})

	return {
		id: uuid(),
		graph,
		paths,
		x: 0,
		y: 0,
		pathTaken: [[0, 0]],
	}
}

/**
 * Returns a "graph" array representation of the map we want to render.
 * Each nested array represents a floor with nodes.
 * All nodes have a type.
 * Nodes with type of `false` are filler nodes nededed for the layout.
	```
	graph = [
		[startNode]
		[node, node, node],
		[node, node, node],
		[node, node, node],
		[bossNode]
	]
	```
 * @param {GraphOptions} [options]
 * @returns {Graph}
 */
export function generateGraph(options) {
	options = Object.assign(defaultOptions, options || {})
	const {width, height, minRooms, maxRooms, roomTypes} = options

	const graph = []

	// Fill up each floor with nodes.
	for (let floorNumber = 0; floorNumber < height; floorNumber++) {
		const floor = []

		// On each floor, X amount of nodes contain an actual room
		let desiredAmountOfRooms = randomBetween(minRooms, maxRooms)
		if (desiredAmountOfRooms > width) desiredAmountOfRooms = width

		// Create the "room" nodes
		for (let i = 0; i < desiredAmountOfRooms; i++) {
			const nodeType = decideNodeType(roomTypes, floorNumber)
			floor.push(createMapNode(nodeType))
		}

		// And fill it up with "empty" nodes.
		while (floor.length < width) {
			floor.push(createMapNode())
		}

		// Randomize the order.
		graph.push(shuffle(floor))
	}

	// Finally, add start end end nodes, in this order.
	graph.unshift([createMapNode('start')])
	graph.push([createMapNode('boss')])

	return graph
}

/**
 * Returns an array of possible paths from start to finish.
 * @param {Graph} graph - dungeon graph
 * @param {string} [customPaths]
 * @returns {Array<Path>} customPaths a list of paths
 */
export function generatePaths(graph, customPaths) {
	const paths = []

	if (customPaths) {
		Array.from(customPaths).forEach((value) => {
			const path = findPath(graph, Number(value))
			paths.push(path)
		})
	} else {
		// Otherwise draw a path for each column.
		graph[1].forEach((_column, index) => {
			const path = findPath(graph, index)
			paths.push(path)
		})
	}

	return paths
}

/**
 * Ensures it's not a filler node
 * @param {MapNode} node
 * @returns {boolean}
 */
function validNode(node) {
	return node && Boolean(node.type)
}

/**
 * Finds a path from start to finish in the graph.
 * Starting node connects to all nodes on the first floor
 * End node connects to all nodes on the last floor
 * It is Y/X, not X/Y (think floor/room, not room/floor)
 * [
 * [[0, 0], [1,4]], <-- first move is from 0,0 to 1,4
 * [[1, 4], [2,1]] <-- second move is from 1,4 to 2,1
 *]
 * @param {Graph} graph
 * @param {number} preferredIndex the column you'd like the path to follow where possible
 * @param {boolean} debug if true, logs to console
 * @returns {Path} an array of moves. Each move contains the Y/X coords of the graph.
 */
function findPath(graph, preferredIndex, debug = false) {
	if (debug) console.groupCollapsed('finding path', preferredIndex)

	const path = []
	/** @type {MapNode|false} */
	let lastVisited = false

	// Walk through each floor.
	for (const [floorIndex, floor] of graph.entries()) {
		if (debug) console.group(`floor ${floorIndex}`)

		// If on last floor, stop moving.
		const nextFloor = graph[floorIndex + 1]
		if (!nextFloor) {
			if (debug) console.log('no next floor, stopping')
			if (debug) console.groupEnd()
			break
		}

		// Find the "a" node we came FROM.
		const aIndex = lastVisited ? floor.indexOf(lastVisited) : 0
		const moveFrom = [floorIndex, aIndex]
		if (debug) console.log('setting from', moveFrom)

		// Find the "b" node we are going TO.
		const bInfo =
			searchValidNode(nextFloor, preferredIndex, 'forward') || searchValidNode(nextFloor, preferredIndex, 'backward')
		if (!bInfo) throw Error('failed to find node to move to')
		const moveTo = [floorIndex + 1, bInfo.index]
		// Store it for later
		lastVisited = bInfo.node

		const move = [moveFrom, moveTo]
		path.push(move)

		if (debug) {
			console.log(`added move to path ${moveFrom} to ${moveTo}`)
			console.groupEnd()
		}
	}

	storePathOnGraph(graph, path)

	if (debug) console.groupEnd()

	return path
}

/**
 * Searches for the first valid node in a direction
 * @param {Array<MapNode>} floor
 * @param {number} startX - the index to start search from
 * @param {string} direction must be "forward" or "backward"
 * @returns {{node: MapNode, index: number}|null}
 */
function searchValidNode(floor, startX, direction) {
	const step = direction === 'forward' ? 1 : -1
	if (direction === 'forward') {
		for (let i = startX; i >= 0 && i < floor.length; i += step) {
			const node = floor[i]
			if (validNode(node)) {
				return {node, index: i}
			}
		}
	} else {
		for (let i = startX; i >= 0; i += step) {
			const node = floor[i]
			if (validNode(node)) {
				return {node, index: i}
			}
		}
	}
	return null
}

/**
 * For debugging purposes, creates a multi-line text representation of the map.
 * @param {Graph} graph
 * @returns {string}
 */
export function graphToString(graph) {
	const textGraph = graph.map((floor) =>
		floor.map((node) => {
			return emojiFromNodeType(node.type)
		}),
	)
	const str = textGraph.map((floor) => floor.join('')).join('\n')
	return str
}

/**
 * Stores a path directly on a graph
 * @param {Graph} graph
 * @param {Path} path
 * @returns {Graph}
 */
export function storePathOnGraph(graph, path) {
	path.forEach((move) => {
		const a = nodeFromMove(graph, move[0])
		const b = nodeFromMove(graph, move[1])

		// @todo refactor so we don't have to do this. Depending on how the dungeon (and graph) was generated, the edges might not be set.
		if (!Array.isArray(a.edges)) {
			a.edges = []
		}
		if (!Array.isArray(b.edges)) {
			b.edges = []
		}

		if (!a.edges.includes(b.id)) {
			a.edges.push(b.id)
		}
	})
	return graph
}

/**
 * @param {Graph} graph
 * @param {Move} move
 * @returns {MapNode}
 */
function nodeFromMove(graph, [floor, node]) {
	return graph[floor][node]
}

/** @enum {string} different type of nodes and their emoji equivalents */
export const MapNodeTypes = {
	start: '👣',
	M: '💀',
	C: '🏕️',
	// $: '💰'
	Q: '❓',
	E: '👹',
	boss: '🌋',
}

export function nodeTypeToName(nodeType) {
	return {
		start: '起点',
		C: '篝火',
		M: '怪物',
		E: '精英怪物',
		boss: '首领',
	}[nodeType]
}

/**
 * A node in the dungeon map graph
 * @param {MapNodeTypes} [type] - a string key to represent the type of room
 * @returns {MapNode}
 */
function createMapNode(type) {
	return {
		id: uuid(),
		type: type,
		room: undefined,
		edges: [],
		didVisit: false,
	}
}

/**
 * The type of node is decided by the floor number and the room types.
 * @param {MapNodeTypes} nodeTypes - a string of possible node types
 * @param {number} [floor] - useful for balance e.g. more monsters on higher floors
 * @returns {string} a single character representing the node type
 */
function decideNodeType(nodeTypes, floor) {
	if (floor < 2) return 'M'
	if (floor < 3) return pick('MC')
	if (floor > 6) return pick('MMEEC')
	return pick(nodeTypes)
}

/**
 * Converts the string type of a node to an emoji string.
 * if node type is supplied it'll use ' ' whitespace as type
 * @param {string} [type] - a string key to represent the type of room
 * @returns {string} a single emoji
 */
export function emojiFromNodeType(type) {
	if (!type) return ' '
	return MapNodeTypes[type]
}

/**
 * Create a room from the node's type
 * @param {string} type
 * @param {number} floor
 * @returns {Room}
 */
export function decideRoomType(type, floor) {
	const pickRandomFromObj = (obj) => obj[shuffle(Object.keys(obj))[0]]
	if (floor === 0) return StartRoom()
	if (type === 'C') return CampfireRoom()
	if (type === 'M' && floor < 2) return pickRandomFromObj(monsters) // @todo slightly easier?
	if (type === 'M') return pickRandomFromObj(monsters)
	if (type === 'E') return pickRandomFromObj(elites)
	if (type === 'boss') return pickRandomFromObj(bosses)
	throw new Error(`Could not match node type "${type}" with a dungeon room`)
}
